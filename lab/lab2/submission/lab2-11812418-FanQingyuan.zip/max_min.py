def find_max_min(list):
    list_max = max(list)
    list_min = min(list)
    return list_max, list_min