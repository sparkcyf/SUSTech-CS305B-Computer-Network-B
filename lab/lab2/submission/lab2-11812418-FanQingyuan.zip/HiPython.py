def HiPython():
    print("hi, I’m programing in \"python\"")