class cat:
    def __init__(self, name):
        self.name = name
    def meow(self):
        return self.name + " meow"
